package databaseCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateDatabaseMethod {
	   public void createDatabase() {
		   try {
			   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa", "root", "toor");
			   String create = "CREATE TABLE IF NOT EXISTS studentinfo ( regno int, rollno int(100) PRIMARY KEY, studentname varchar(100), fathername varchar(100), mothername varchar(100), course varchar(100), sem varchar(100), year varchar(100));";
			   Statement stmt = conn.createStatement();
			   stmt.executeUpdate(create);
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }
	   }
}

package databaseCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetEntries {

public String getstudentname(String index, String rollNo) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");
		String topic_name = null;
		String wr = "Select * from studentinfo WHERE regno = '"+index+"' AND rollno = '"+rollNo+"';";

		Statement stm = conn.createStatement();
		ResultSet rs = stm.executeQuery(wr);

		while (rs.next()) {
			topic_name = rs.getString("studentname");
		}
		
		
		return topic_name;
	}

public  String getfathername(String index, String rollNo) throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");

	String topic_name = null;
	
	String wr = "Select * from studentinfo WHERE regno = '"+index+"' AND rollno = '"+rollNo+"';";

	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery(wr);

	while (rs.next()) {
		topic_name = rs.getString("fathername");
	}
	
	
	return topic_name;
}


public  String getmothername(String index, String rollNo) throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");

	String topic_name = null;
	
	String wr = "Select * from studentinfo WHERE regno = '"+index+"' AND rollno = '"+rollNo+"';";

	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery(wr);

	while (rs.next()) {
		topic_name = rs.getString("mothername");
	}
	
	
	return topic_name;
}


public  String getcourse(String index, String rollNo) throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");

	String topic_name = null;
	
	String wr = "Select * from studentinfo WHERE regno = '"+index+"' AND rollno = '"+rollNo+"';";

	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery(wr);

	while (rs.next()) {
		topic_name = rs.getString("course");
	}
	
	
	return topic_name;
}


public  String getyear(String index, String rollNo) throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");

	String topic_name = null;
	
	String wr = "Select * from studentinfo WHERE regno = '"+index+"' AND rollno = '"+rollNo+"';";

	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery(wr);

	while (rs.next()) {
		topic_name = rs.getString("year");
	}
	
	
	return topic_name;
}


public  String getsem(String index, String rollNo) throws ClassNotFoundException, SQLException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");

	String topic_name = null;
	
	String wr = "Select * from studentinfo WHERE regno = '"+index+"' AND rollno = '"+rollNo+"';";

	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery(wr);

	while (rs.next()) {
		topic_name = rs.getString("sem");
	}
	
	
	return topic_name;
}

public void updateTopic(String regno, String rollno, String studentname, String fathername, String mothername, String course, String year, String sem) throws ClassNotFoundException, SQLException {
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");
	
	String insert = "UPDATE studentinfo SET regno = '"+ regno +"', rollno = '"+ rollno +"', name = '"+ studentname +"', fname = '"+ fathername +"', mname = '"+ mothername +"', course = '"+ course +"', sem = '"+ sem +"', year = '"+ year +"';";
	Statement stat = conn.createStatement();
	stat.executeUpdate(insert);

}

public void removeTopic(String regno, String rollno) throws SQLException, ClassNotFoundException {
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa?useSSL=false", "root", "toor");
	
	String insert = "DELETE FROM studentinfo where regno = '"+regno +"' AND rollno = '"+rollno+"';";
	Statement stat = conn.createStatement();
	stat.executeUpdate(insert);
 }

}

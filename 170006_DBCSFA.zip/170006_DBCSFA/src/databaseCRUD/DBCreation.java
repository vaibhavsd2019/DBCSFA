package databaseCRUD;
import java.sql.*;

public class DBCreation {
   // JDBC driver name and database URL
   static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost:3306/";

   //  Database credentials
   static final String USER = "root";
   static final String PASS = "toor";
   
   public void createDB() {
   Connection conn = null;
   Statement stmt = null;
   try{
    
      Class.forName("com.mysql.cj.jdbc.Driver");
      conn = DriverManager.getConnection(DB_URL, USER, PASS);
      stmt = conn.createStatement();
      String sql = "CREATE DATABASE IF NOT EXISTS dbcsfa";
      stmt.executeUpdate(sql);
      System.out.println("!!!!Database Creation and Connection Successful!!!!");
     }catch(SQLException se){
      se.printStackTrace();
      }catch(Exception e){
      e.printStackTrace();
     } 
  }
}
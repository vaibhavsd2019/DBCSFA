package databaseCRUD;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PushEntries {

	public static void insert(String regno, String rollno, String studentname, String fathername, String mothername, String course, String year, String sem) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbcsfa", "root", "toor");
			con.setAutoCommit(false);
			PreparedStatement pstmt = null;
			
		    String sql = "INSERT INTO studentinfo (regno, rollno, studentname, fathername, mothername, course, sem, year) VALUES('" + regno + "','" + rollno + "','" + studentname
						+ "','" + fathername + "','" + mothername + "','" + course + "','" + sem + "','"
						+ year +"')";
				pstmt = (PreparedStatement) con.prepareStatement(sql);
				pstmt.execute();
			
			con.commit();
			pstmt.close();
			con.close();
		
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		}

	}
}
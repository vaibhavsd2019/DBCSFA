package applicationGUI;

import java.sql.SQLException;

import databaseCRUD.GetEntries;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

public class ModifyUI {
private Label lbl_title = new Label("Student Registration");
	
	private Label lbl_no = new Label("Registration Number");
	private Label lbl_rollno = new Label("Roll No");
	
	private Label lbl_success = new Label("");
	
	static TextField txt_regnof = new TextField();
	static TextField txt_rollnof = new TextField();
	
	private Button btn_Modify = new Button("Modify Entry");
	private Button btn_delete = new Button("Delete Entry");
	
	GetEntries ge = new GetEntries();
	
	protected Window theStage;
	
	public UpdationUI uploadUI;

	public ModifyUI(Pane uploadPane, Stage thisStage) {

		setupLabelUI(lbl_title, "Arial", 30, 50, Pos.BASELINE_CENTER, 200, 20);
		lbl_title.setFont(Font.font("Arial", FontWeight.BOLD, 20));

		setupLabelUI(lbl_no, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 80);
		setupLabelUI(lbl_rollno, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 120);
		setupLabelUI(lbl_success, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 450);

		
		setupButtonUI(btn_Modify, "Arial", 15, 50, Pos.BASELINE_CENTER, 200, 425);
		setupButtonUI(btn_delete, "Arial", 15, 50, Pos.BASELINE_CENTER, 350, 425);
		 
		setupTextUI(txt_regnof, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 75, true);
		setupTextUI(txt_rollnof, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 115, true);
		
		btn_Modify.setOnAction(e -> {
			uploadWindow();
		});
		
		btn_delete.setOnAction(e -> {
			try {
				delete();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		
		
		uploadPane.getChildren().addAll(lbl_title, txt_regnof, lbl_success, lbl_no, lbl_rollno, txt_rollnof, btn_Modify, btn_delete);
	}

	private void uploadWindow() {
		
		if( ! txt_regnof.getText().toString().isEmpty() && ! txt_rollnof.getText().toString().isEmpty()) {
			Stage uploadStage = new Stage();
			uploadStage.setTitle("Modify");
			Pane uploadPane = new Pane();
			uploadUI = new UpdationUI(uploadPane, uploadStage);
			Scene uploadScene = new Scene(uploadPane, 600, 500);
			uploadStage.setScene(uploadScene);
			uploadStage.show();
		}
		
	}
	
	private void delete() throws ClassNotFoundException, SQLException {
		String reg = null;
		String rollno =  null;
		
		if(! txt_regnof.getText().toString().isEmpty()) {
			 reg = txt_regnof.getText().toString();
		}
		if(! txt_rollnof.getText().toString().isEmpty()) {
			 rollno = txt_rollnof.getText().toString();
		}
		
		ge.removeTopic(reg, rollno);
		lbl_success.setText("Entry is successfully deleted");
		
	}
	
	
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	private void setupComboUI(ComboBox<String> combo, double w, Pos p, double x, double y, boolean e) {
		combo.setMinWidth(w);
		combo.setLayoutX(x);
		combo.setLayoutY(y);
		combo.setEditable(e);
	}

}

package applicationGUI;


import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import databaseCRUD.CreateDatabaseMethod;
import databaseCRUD.DBCreation;
import databaseCRUD.PushEntries;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

public class UserInterface {
	
	CreateDatabaseMethod cr = new CreateDatabaseMethod();
	DBCreation createdb = new DBCreation();
	PushEntries push = new PushEntries();
	
	private Label lbl_title = new Label("Student Registration");
	
	private Label lbl_no = new Label("Registration Number");
	private Label lbl_rollno = new Label("Roll No");
	private Label lbl_studentname = new Label("Student Name");
	private Label lbl_fathername = new Label("Father Name");
	private Label lbl_mothername = new Label("Mother Name");
	private Label lbl_course = new Label("Course");
	private Label lbl_sem = new Label("Semester");
	private Label lbl_year = new Label("Year");
	
	
	private TextField txt_regno = new TextField();
	private TextField txt_rollno = new TextField();
	private TextField txt_studentname = new TextField();
	private TextField txt_fathername = new TextField();
	private TextField txt_mothername = new TextField();
	private TextField txt_course = new TextField();
	private TextField txt_year = new TextField();
	private TextField txt_sem = new TextField();

	private Button btn_CreateNew = new Button("Create New Entry");
	private Button btn_Modify = new Button("Modify Entry");
	private Button btn_delete = new Button("Delete Entry");
	private Button btn_pdf = new Button("View PDF");
	
	protected Window theStage;
	
	public UpdationUI uploadUI;
	public ModifyUI seen;
	
	public UserInterface(Pane theRoot) {
		setupLabelUI(lbl_title, "Arial", 30, 50, Pos.BASELINE_CENTER, 400, 20);
		lbl_title.setFont(Font.font("Arial", FontWeight.BOLD, 20));

		setupLabelUI(lbl_no, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 80);
		setupLabelUI(lbl_rollno, "Arial", 15, 50, Pos.BASELINE_CENTER, 510, 80);
		setupLabelUI(lbl_studentname, "Arial", 15, 50, Pos.BASELINE_CENTER, 280, 140);
		setupLabelUI(lbl_fathername, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 200);
		setupLabelUI(lbl_mothername, "Arial", 15, 50, Pos.BASELINE_CENTER, 510, 200);
		setupLabelUI(lbl_course, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 260);
		setupLabelUI(lbl_sem, "Arial", 15, 50, Pos.BASELINE_CENTER, 510, 260);
		setupLabelUI(lbl_year, "Arial", 15, 50, Pos.BASELINE_CENTER, 280, 300);
		
		setupTextUI(txt_regno, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 75, true);
		setupTextUI(txt_rollno, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 600, 75, true);
		setupTextUI(txt_studentname, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 400, 135, true);
		setupTextUI(txt_fathername, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 195, true);
		setupTextUI(txt_mothername, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 650, 195, true);
		setupTextUI(txt_course, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 250, true);
		setupTextUI(txt_sem, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 600, 250, true);
		setupTextUI(txt_year, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 400, 290, true);
		
		

		setupButtonUI(btn_CreateNew, "Arial", 15, 50, Pos.BASELINE_CENTER, 150, 380);
		setupButtonUI(btn_Modify, "Arial", 15, 50, Pos.BASELINE_CENTER, 400, 380);
		setupButtonUI(btn_delete, "Arial", 15, 50, Pos.BASELINE_CENTER, 600, 380);
		setupButtonUI(btn_pdf, "Arial", 15, 50, Pos.BASELINE_CENTER, 800, 380);
		 
		
		btn_CreateNew.setOnAction(e -> {
			createTable();
		});
		
		btn_Modify.setOnAction(e -> {
			updateWindow();
		});
		
		btn_delete.setOnAction(e -> {
			updateWindow();
		});
		
		btn_pdf.setOnAction(e -> {
			try {
				viewPDF();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (DocumentException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		theRoot.getChildren().addAll(lbl_title, txt_regno, btn_CreateNew, lbl_no, lbl_rollno, lbl_studentname, lbl_fathername, lbl_mothername, lbl_year,
				lbl_course, lbl_sem, txt_rollno, txt_studentname, txt_fathername, txt_mothername, txt_sem, txt_year, txt_course
				, btn_Modify, btn_delete, btn_pdf);

	}

	
	private void viewPDF() throws SQLException, DocumentException, ClassNotFoundException, IOException {
		
		Document document = new Document();
		PdfWriter.getInstance(document,
				new FileOutputStream("E:/finalexam.pdf"));
		document.open();
		File f = new File("E:/finalexam.pdf");

		PdfPTable table = new PdfPTable(8);
		table.addCell("Reg");
		table.addCell("Roll No");
		table.addCell("Name");
		table.addCell("Father Name");
		table.addCell("Mother Name");
		table.addCell("Course");
		table.addCell("Semester");
		table.addCell("Year");
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3305/dbcsfinal", "root",
				"root@123");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * from student_data");
		while (rs.next()) {
			table.addCell(rs.getString("reg"));
			table.addCell(rs.getString("rollno"));
			table.addCell(rs.getString("name"));
			table.addCell(rs.getString("fname"));
			table.addCell(rs.getString("mname"));
			table.addCell(rs.getString("course"));
			table.addCell(rs.getString("sem"));
			table.addCell(rs.getString("year"));
		}
		document.add(table);
		document.close();
		Desktop.getDesktop().open(f);
	
	
}

	

	private void updateWindow() {
		
		Stage updateStage = new Stage();
		updateStage.setTitle("Select Entry");
		Pane uploadPane = new Pane();
		seen = new ModifyUI(uploadPane, updateStage);
		Scene uploadScene = new Scene(uploadPane, 600, 500);
		updateStage.setScene(uploadScene);
		updateStage.show();

	}
	
	private void createTable() {
		createdb.createDB();
		cr.createDatabase();
		String regno = null;
		String rollno =  null;
		String studentname = null;
		String fathername = null;
		String mothername = null;
		String course = null;
		String year = null;
		String sem = null;
		
		if(! txt_regno.getText().toString().isEmpty()) {
			 regno = txt_regno.getText().toString();
		}
		if(! txt_rollno.getText().toString().isEmpty()) {
			 rollno = txt_rollno.getText().toString();
		}
		if(! txt_studentname.getText().toString().isEmpty()) {
			 studentname = txt_studentname.getText().toString();
		}
		if(! txt_fathername.getText().toString().isEmpty()) {
			 fathername = txt_fathername.getText().toString();
		}
		if(! txt_mothername.getText().toString().isEmpty()) {
			 mothername = txt_mothername.getText().toString();
		}
		if(! txt_course.getText().toString().isEmpty()) {
			 course = txt_course.getText().toString();
		}
		if(! txt_sem.getText().toString().isEmpty()) {
			 sem = txt_sem.getText().toString();
		}
		if(! txt_year.getText().toString().isEmpty()) {
			 year = txt_year.getText().toString();
		}
		
		PushEntries.insert(regno, rollno, studentname, fathername, mothername, course, year, sem);
		
	}

	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
	
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

}

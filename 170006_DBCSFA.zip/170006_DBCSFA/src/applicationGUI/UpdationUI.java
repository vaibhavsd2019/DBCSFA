package applicationGUI;

import java.sql.SQLException;

import databaseCRUD.GetEntries;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.Window;

public class UpdationUI {
private Label lbl_title = new Label("Student Registration");
	
	private Label lbl_no = new Label("Registration Number");
	private Label lbl_rollno = new Label("Roll No");
	private Label lbl_studentname = new Label("Student Name");
	private Label lbl_fathername = new Label("Father Name");
	private Label lbl_mothername = new Label("Mother Name");
	private Label lbl_course = new Label("Course");
	private Label lbl_sem = new Label("Semester");
	private Label lbl_year = new Label("Year");
	
	
	private TextField txt_regno = new TextField();
	private TextField txt_rollno = new TextField();
	private TextField txt_studentname = new TextField();
	private TextField txt_fathername = new TextField();
	private TextField txt_mothername = new TextField();
	private TextField txt_course = new TextField();
	private TextField txt_year = new TextField();
	private TextField txt_sem = new TextField();


	private Button btn_Modify = new Button("Modify Entry");
	
	protected Window theStage;
	
	public UpdationUI uploadUI;

	GetEntries getentry = new GetEntries();
	
	Stage win = new Stage();
	Pane winpane = new Pane();
	ModifyUI se = new ModifyUI(winpane, win);
	
	public UpdationUI(Pane uploadPane, Stage thisStage) {

		setupLabelUI(lbl_title, "Arial", 30, 50, Pos.BASELINE_CENTER, 200, 20);
		lbl_title.setFont(Font.font("Arial", FontWeight.BOLD, 20));

		setupLabelUI(lbl_no, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 80);
		setupLabelUI(lbl_rollno, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 120);
		setupLabelUI(lbl_studentname, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 160);
		setupLabelUI(lbl_fathername, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 200);
		setupLabelUI(lbl_mothername, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 240);
		setupLabelUI(lbl_course, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 280);
		setupLabelUI(lbl_sem, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 320);
		setupLabelUI(lbl_year, "Arial", 15, 50, Pos.BASELINE_CENTER, 20, 360);
	
		setupButtonUI(btn_Modify, "Arial", 15, 50, Pos.BASELINE_CENTER, 200, 425);
		 
		setupTextUI(txt_regno, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 75, true);
		setupTextUI(txt_rollno, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 115, true);
		setupTextUI(txt_studentname, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 155, true);
		setupTextUI(txt_fathername, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 195, true);
		setupTextUI(txt_mothername, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 235, true);
		setupTextUI(txt_course, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 275, true);
		setupTextUI(txt_sem, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 315, true);
		setupTextUI(txt_year, "Arial", 14, 250, 150, Pos.BASELINE_LEFT, 200, 355, true);
		

		
		
		String name = null;
		try {
			name = getentry.getstudentname(se.txt_regnof.getText().toString(), se.txt_rollnof.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String fathername = null;
		try {
			fathername = getentry.getfathername(se.txt_regnof.getText().toString(), se.txt_rollnof.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String mothername = null;
		try {
			mothername = getentry.getmothername(se.txt_regnof.getText().toString(), se.txt_rollnof.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String course = null;
		try {
			course = getentry.getcourse(se.txt_regnof.getText().toString(), se.txt_rollnof.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String year = null;
		try {
			year = getentry.getyear(se.txt_regnof.getText().toString(), se.txt_rollnof.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sem = null;
		try {
			sem = getentry.getsem(se.txt_regnof.getText().toString(), se.txt_rollnof.getText().toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		txt_regno.setText(se.txt_regnof.getText().toString());
		txt_rollno.setText(se.txt_rollnof.getText().toString());
		txt_studentname.setText(name);
		txt_fathername.setText(fathername);
		txt_mothername.setText(mothername);
		txt_course.setText(course);
		txt_year.setText(year);
		txt_sem.setText(sem);
		
		
		btn_Modify.setOnAction(e -> {
			try {
				uploadWindow();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		uploadPane.getChildren().addAll(lbl_title, txt_regno, lbl_no, lbl_rollno, lbl_studentname, lbl_fathername, lbl_mothername, lbl_year,
				lbl_course, lbl_sem, txt_rollno, txt_studentname, txt_fathername, txt_mothername, txt_sem, txt_year, txt_course
				, btn_Modify);
	}

	
private void uploadWindow() throws ClassNotFoundException, SQLException {
		
	System.out.println(se.txt_regnof.getText().toString());
	System.out.println(se.txt_rollnof.getText().toString());
	
	String reg = null;
	String rollno =  null;
	String name = null;
	String fathername = null;
	String mothername = null;
	String course = null;
	String year = null;
	String sem = null;
	
	if(! txt_regno.getText().toString().isEmpty()) {
		 reg = txt_regno.getText().toString();
	}
	if(! txt_rollno.getText().toString().isEmpty()) {
		 rollno = txt_rollno.getText().toString();
	}
	if(! txt_studentname.getText().toString().isEmpty()) {
		 name = txt_studentname.getText().toString();
	}
	if(! txt_fathername.getText().toString().isEmpty()) {
		 fathername = txt_fathername.getText().toString();
	}
	if(! txt_mothername.getText().toString().isEmpty()) {
		 mothername = txt_mothername.getText().toString();
	}
	if(! txt_course.getText().toString().isEmpty()) {
		 course = txt_course.getText().toString();
	}
	if(! txt_sem.getText().toString().isEmpty()) {
		 sem = txt_sem.getText().toString();
	}
	if(! txt_year.getText().toString().isEmpty()) {
		 year = txt_year.getText().toString();
	}
	
	getentry.updateTopic(reg, rollno, name, fathername, mothername, course, year, sem);
	
	}

	
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	private void setupComboUI(ComboBox<String> combo, double w, Pos p, double x, double y, boolean e) {
		combo.setMinWidth(w);
		combo.setLayoutX(x);
		combo.setLayoutY(y);
		combo.setEditable(e);
	}

}
